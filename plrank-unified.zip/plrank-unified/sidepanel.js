/**
 * sidepanel.js — 파워링크 순위 체커 v3
 * 키워드 관리 + 광고주 계정 관리 + 전체 스캔 통합
 */
'use strict';

/* ══════════════════════════════════════
   스토리지 키
══════════════════════════════════════ */
const KW_SK   = 'plrank_v2';
const NAV_SK  = 'nav_accounts';
const NAV_FAV = 'nav_favorites';
const NAV_REC = 'nav_recent';
const CFG_SK  = 'config';

/* ══════════════════════════════════════
   상태
══════════════════════════════════════ */
let kws         = [];   // 키워드 목록
let navAccounts = [];   // 광고주 계정
let navFavs     = [];   // 즐겨찾기 ID 배열
let navRecent   = [];   // 최근 방문 [{id, visitedAt}]
let config      = null; // { managerAccountId, divisionName }

let navQuery    = '';   // 광고주 검색어
let navEditingId = null; // 수정 중인 계정 ID

// 스캔 상태
let scanActive  = false;
let scanTotal   = 0;
let scanDone    = 0;
let scanResults = [];
let openTabMap  = {};
let activeAdv   = '__all__';

// 대량 등록 파싱 임시
let kwBulkRows  = [];
let navPasteRows = [];

/* ══════════════════════════════════════
   URL 빌더
══════════════════════════════════════ */
function naverSearchUrl(kw, usePowerlink, useMobile) {
  const q = encodeURIComponent(kw.trim());
  if (useMobile)    return `https://m.ad.search.naver.com/search.naver?where=m_expd&query=${q}`;
  if (usePowerlink) return `https://ad.search.naver.com/search.naver?where=ad&query=${q}`;
  return `https://search.naver.com/search.naver?query=${q}`;
}

/**
 * 광고주센터 URL — accessManagerAccountNo는 ⚙️ 설정값(config.managerAccountId) 무조건 사용
 * 계정별 managerAccountId는 URL에 절대 사용 안 함 (상위계정 노출 방지)
 */
function buildAdCenterUrl(linkedAccountId) {
  if (!linkedAccountId) return null;
  const acc = navAccounts.find(a => a.accountId === linkedAccountId);
  const accountId = acc ? acc.accountId : linkedAccountId;
  return buildAdCenterUrlDirect(accountId);
}

function buildAdCenterUrlDirect(accountId) {
  if (!accountId) return null;
  const mgr = config?.managerAccountId || '';
  if (!mgr) return null;
  return `https://ads.naver.com/manage/ad-accounts/${accountId}/dashboard?accessManagerAccountNo=${mgr}`;
}

function surfaceLabel(usePowerlink, useMobile) {
  if (useMobile)    return '📱 모바일';
  if (usePowerlink) return '🖥️ 더보기';
  return '';
}

/* ══════════════════════════════════════
   색상 분류
══════════════════════════════════════ */
function rankSt(lastRank, lastCheckedAt, targetRank) {
  if (lastRank == null) return lastCheckedAt ? 'miss' : 'none';
  if (lastRank < targetRank)   return 'better';
  if (lastRank === targetRank) return 'good';
  return 'bad';
}

/* ══════════════════════════════════════
   초기화
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', async () => {
  const d = await chrome.storage.local.get([KW_SK, NAV_SK, NAV_FAV, NAV_REC, CFG_SK]);
  kws         = d[KW_SK]  || [];
  navAccounts = d[NAV_SK] || [];
  navFavs     = d[NAV_FAV]|| [];
  navRecent   = d[NAV_REC]|| [];
  config      = d[CFG_SK] || null;

  // 기존 데이터 마이그레이션
  kws.forEach(k => {
    if (k.usePowerlink   === undefined) k.usePowerlink  = false;
    if (k.useMobile      === undefined) k.useMobile     = false;
    if (k.linkedAccountId=== undefined) k.linkedAccountId = '';
  });

  // 관리계정 미설정 시 초기 설정 화면
  if (!config?.managerAccountId) showSetup();

  initTabs();
  initHeaderBtns();
  initSetup();
  initKwPanel();
  initNavPanel();
  initScanPanel();
  initQA();
  initModalClose();
  renderKw();
  renderNav();
  refreshTs();
});

/* ── storage 변경 감지 ── */
let _navSkipNextChange = false; // 내부 저장 시 중복 렌더 방지

chrome.storage.onChanged.addListener(async (changes) => {
  if (changes[KW_SK])  { kws  = changes[KW_SK].newValue  || []; renderKw(); }
  if (changes[NAV_SK]) {
    navAccounts = changes[NAV_SK].newValue || [];
    if (_navSkipNextChange) { _navSkipNextChange = false; }
    else { renderNav(); renderKw(); }
  }
  if (changes[NAV_FAV]){ navFavs = changes[NAV_FAV].newValue || []; renderNav(); }
  if (changes[CFG_SK]) { config  = changes[CFG_SK].newValue || null; }

  // 스캔 완료 신호
  for (const key of Object.keys(changes)) {
    if (!key.startsWith('__plrank_done_')) continue;
    const val = changes[key].newValue;
    if (!val || !scanActive) continue;

    const kw = val.keyword;

    const fr = await chrome.storage.local.get(KW_SK);
    const fk = fr[KW_SK] || [];

    // 해당 keyword 항목 모두 업데이트 (지면별 구분)
    fk.filter(k => k.keyword.trim().toLowerCase() === kw.trim().toLowerCase())
      .forEach(item => {
        const resIdx = scanResults.findIndex(r =>
          r.itemId === item.id ||
          (r.keyword === item.keyword &&
           r.usePowerlink === (item.usePowerlink||false) &&
           r.useMobile    === (item.useMobile||false))
        );
        const card = {
          itemId: item.id, keyword: item.keyword, advertiser: item.advertiser||'',
          url: item.url||'', currentRank: item.lastRank,
          targetRank: item.targetRank||3, diff: item.diff||'-',
          usePowerlink: item.usePowerlink||false, useMobile: item.useMobile||false,
          linkedAccountId: item.linkedAccountId||'',
        };
        if (resIdx >= 0) scanResults[resIdx] = card; else scanResults.push(card);
      });

    await chrome.storage.local.remove(key);

    // 해당 keyword 탭 하나 닫기
    for (const tid of Object.keys(openTabMap)) {
      const v   = openTabMap[tid];
      const tKw = typeof v === 'string' ? v : v?.keyword;
      if (tKw?.trim().toLowerCase() === kw.trim().toLowerCase()) {
        const numTid = Number(tid);
        if (!isNaN(numTid)) {
          try { await chrome.tabs.remove(numTid); } catch (e) { console.warn('[PLR] 탭 닫기 실패:', e.message); }
        }
        delete openTabMap[tid];
        break;
      }
    }

    scanDone++;
    updateScanProgress();
    renderResultCards();
    updateAdvFilter();

    const scanTabsForStorage = {};
    Object.entries(openTabMap).forEach(([tid, v]) => {
      scanTabsForStorage[tid] = typeof v === 'string' ? v : v.keyword;
    });
    await chrome.storage.local.set({ __plrank_scan_tabs__: scanTabsForStorage });

    if (scanDone >= scanTotal) finishScan();
  }
});

/* ══════════════════════════════════════
   초기 설정 화면
══════════════════════════════════════ */
function showSetup() {
  document.getElementById('setupOverlay').classList.add('open');
  setTimeout(() => document.getElementById('setupMgrId').focus(), 100);
}
function initSetup() {
  document.getElementById('setupConfirm').addEventListener('click', handleSetupConfirm);
  document.getElementById('setupSkip').addEventListener('click', () => {
    document.getElementById('setupOverlay').classList.remove('open');
  });
  // Enter 키 지원 — 두 입력 필드 모두
  ['setupMgrId', 'setupDivName'].forEach(id => {
    document.getElementById(id).addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); handleSetupConfirm(); }
    });
  });
}
async function handleSetupConfirm() {
  const id  = document.getElementById('setupMgrId').value.trim();
  const div = document.getElementById('setupDivName').value.trim();
  if (id && !/^\d+$/.test(id)) {
    document.getElementById('setupErr').style.display = 'block';
    return;
  }
  document.getElementById('setupErr').style.display = 'none';
  if (id) {
    config = { managerAccountId: id, divisionName: div };
    await chrome.storage.local.set({ [CFG_SK]: config });
  }
  document.getElementById('setupOverlay').classList.remove('open');
  toast('설정이 저장되었습니다');
}

/* ══════════════════════════════════════
   탭 전환
══════════════════════════════════════ */
function initTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => switchTab(tab.dataset.tab));
  });
}
function switchTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === 'panel-' + name));
}

/* ══════════════════════════════════════
   헤더 버튼
══════════════════════════════════════ */
function initHeaderBtns() {
  document.getElementById('btnSave').addEventListener('click', saveAllKw);
  document.getElementById('btnCSV').addEventListener('click', downloadCSV);
}

/* ══════════════════════════════════════
   모달 공통 닫기
══════════════════════════════════════ */
function initModalClose() {
  document.querySelectorAll('.modal-close, [data-modal]').forEach(el => {
    el.addEventListener('click', () => {
      const id = el.dataset.modal || el.closest('.modal')?.id;
      if (id) closeModal(id);
    });
  });
  document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) closeModal(m.id); });
  });
}
function openModal(id)  { document.getElementById(id).classList.add('open');    }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

/* ══════════════════════════════════════
   QA 아코디언
══════════════════════════════════════ */
function initQA() {
  document.querySelectorAll('.qa-q').forEach(q => {
    q.addEventListener('click', () => {
      const qa = q.closest('.qa');
      const open = qa.classList.contains('open');
      document.querySelectorAll('.qa').forEach(x => x.classList.remove('open'));
      if (!open) qa.classList.add('open');
    });
  });
}

/* ══════════════════════════════════════
   ① 키워드 패널
══════════════════════════════════════ */
function initKwPanel() {
  document.getElementById('btnKwAdd').addEventListener('click', () => {
    kws.push({ id: uid(), advertiser:'', keyword:'', url:'', targetRank:3,
      usePowerlink:false, useMobile:false, linkedAccountId:'',
      lastRank:null, prevRank:null, diff:'-', lastCheckedAt:null });
    renderKw();
    const cards = document.querySelectorAll('.kw-card');
    cards[cards.length-1]?.querySelector('.kw-adv-inp')?.focus();
  });

  document.getElementById('btnKwBulk').addEventListener('click', () => {
    kwBulkRows = [];
    document.getElementById('kwBulkTa').value = '';
    document.getElementById('kwBulkOk').classList.remove('show');
    document.getElementById('kwBulkErr').classList.remove('show');
    document.getElementById('kwBulkStatus').textContent = '키워드를 붙여넣으세요';
    document.getElementById('kwBulkConfirm').disabled = true;
    openModal('kwBulkModal');
    setTimeout(() => document.getElementById('kwBulkTa').focus(), 100);
  });

  const ta = document.getElementById('kwBulkTa');
  ta.addEventListener('input', () => parseKwBulk(ta.value));
  ta.addEventListener('paste', () => setTimeout(() => parseKwBulk(ta.value), 30));

  document.getElementById('kwBulkConfirm').addEventListener('click', () => {
    if (!kwBulkRows.length) return;
    kws.push(...kwBulkRows.map(r => ({
      id: uid(), advertiser: r.advertiser||'', keyword: r.keyword||'',
      url: r.url||'', targetRank: r.targetRank||3,
      usePowerlink: r.usePowerlink||false,
      useMobile:    r.useMobile||false,
      linkedAccountId: r.linkedAccountId||'',
      lastRank:null, prevRank:null, diff:'-', lastCheckedAt:null
    })));
    saveKw(); renderKw();
    toast(`${kwBulkRows.length}개 키워드 등록 완료`);
    closeModal('kwBulkModal');
  });
}

function parseKwBulk(raw) {
  const lines = raw.split('\n').map(l => l.trimEnd()).filter(l => l.trim());
  const rows = [], errors = [];
  lines.forEach((line, i) => {
    const sep  = line.includes('\t') ? '\t' : ',';
    const cols = line.split(sep).map(c => c.trim());
    const [c0, c1, c2, c3] = cols;
    if (i === 0 && (c0 === '업체명' || c1 === '키워드' || c0 === '키워드')) return;
    let row;
    const parseBool = v => ['y','yes','1','true','더보기','모바일','o'].includes((v||'').toLowerCase().trim());
    if      (cols.length === 1) row = { advertiser:'', keyword:c0, url:'', targetRank:3, usePowerlink:false, useMobile:false };
    else if (cols.length === 2) row = { advertiser:'', keyword:c0, url:c1, targetRank:3, usePowerlink:false, useMobile:false };
    else if (cols.length === 3) row = { advertiser:c0, keyword:c1, url:c2, targetRank:3, usePowerlink:false, useMobile:false };
    else {
      const t  = parseInt(c3);
      const c4 = cols[4]||'', c5 = cols[5]||'';
      row = { advertiser:c0, keyword:c1, url:c2, targetRank:isNaN(t)?3:t,
              usePowerlink: parseBool(c4), useMobile: parseBool(c5) };
    }
    if (!row.keyword) { errors.push(`${i+1}행`); return; }
    rows.push(row);
  });
  kwBulkRows = rows;
  const ok  = document.getElementById('kwBulkOk');
  const err = document.getElementById('kwBulkErr');
  const st  = document.getElementById('kwBulkStatus');
  const btn = document.getElementById('kwBulkConfirm');
  if (rows.length) {
    ok.textContent = `✅ ${rows.length}개 키워드 인식됨 ${errors.length ? `(${errors.length}행 오류)` : ''}`;
    ok.classList.add('show'); err.classList.remove('show');
    st.textContent = `${rows.length}개 키워드를 등록합니다`;
    btn.disabled = false;
  } else {
    ok.classList.remove('show');
    err.textContent = errors.length ? `${errors.join(', ')} 파싱 오류` : '인식된 키워드가 없습니다';
    err.classList.add('show');
    st.textContent = '키워드를 붙여넣으세요';
    btn.disabled = true;
  }
}

/* ── 키워드 렌더 ── */
function renderKw() {
  const list  = document.getElementById('kwList');
  const empty = document.getElementById('kwEmpty');
  document.getElementById('kwCount').textContent = `${kws.length}개`;

  list.querySelectorAll('.kw-card').forEach(c => c.remove());

  if (!kws.length) { empty.style.display = 'flex'; return; }
  empty.style.display = 'none';

  kws.forEach((item, idx) => {
    const card = document.createElement('div');
    card.className = 'kw-card';
    card.innerHTML = buildKwCardHTML(item, idx);
    list.appendChild(card);
    bindKwCardEvents(card, idx);
  });
}

function buildKwCardHTML(item, idx) {
  const st     = rankSt(item.lastRank, item.lastCheckedAt, item.targetRank||3);
  const rb     = rankBadgeHTML(item.lastRank, st);
  const df     = diffHTML(item.diff);
  const ts     = item.lastCheckedAt
    ? new Date(item.lastCheckedAt).toLocaleString('ko-KR', { month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' })
    : '';
  const chkPl  = item.usePowerlink ? 'checked' : '';
  const chkMob = item.useMobile    ? 'checked' : '';

  // linkedAccountId: nav_accounts ID 또는 수동 입력 accountId
  const linkedAcc = navAccounts.find(a => a.accountId === item.linkedAccountId);
  const adUrl = item.linkedAccountId
    ? (buildAdCenterUrlDirect(item.linkedAccountId))
    : null;

  // 드롭다운 옵션 (nav_accounts 목록)
  const navOpts = navAccounts.map(a =>
    `<option value="${esc(a.accountId)}" ${item.linkedAccountId === a.accountId ? 'selected' : ''}>${esc(a.advertiser||a.name)} (${esc(a.accountId)})</option>`
  ).join('');

  // 수동입력 모드 여부: linkedAccountId가 있는데 nav_accounts에 없으면 수동 입력
  const isManual = item.linkedAccountId && !linkedAcc;
  // advertiser 표시: 연결된 계정의 광고주명 or 직접 입력한 advertiser
  const displayAdv = linkedAcc ? (linkedAcc.advertiser||linkedAcc.name) : (item.advertiser||'');

  return `
    <!-- ① 광고주 선택 (최상단) -->
    <div class="kw-adv-section">
      <div class="kw-adv-top">
        <div class="kw-adv-mode-btns">
          <button class="btn-adv-mode ${!isManual?'active':''}" data-mode="dropdown" title="등록된 광고주 선택">드롭다운</button>
          <button class="btn-adv-mode ${isManual?'active':''}" data-mode="manual" title="직접 입력">직접입력</button>
        </div>
        <div class="sf-row">
          <label class="sf-item"><input class="sf-chk cb-pl" type="checkbox" ${chkPl}/><span class="sf-label pl-lbl">더보기</span></label>
          <label class="sf-item mob"><input class="sf-chk cb-mob" type="checkbox" ${chkMob}/><span class="sf-label mob-lbl">모바일</span></label>
        </div>
        <button class="btn-del">✕</button>
      </div>

      <!-- 드롭다운 모드 -->
      <div class="adv-dropdown-wrap ${isManual?'hidden':''}">
        <div class="adlink-wrap">
          <select class="adlink-sel">
            <option value="">── 광고주 선택 ──</option>
            ${navOpts}
          </select>
          <button class="btn-adcenter" ${adUrl && !isManual ? `data-url="${esc(adUrl)}"` : 'disabled'} title="광고주센터 열기">🏢</button>
        </div>
        ${navAccounts.length === 0 ? '<div class="adlink-hint">💡 광고주 탭에서 계정을 먼저 등록하세요</div>' : ''}
      </div>

      <!-- 직접입력 모드 -->
      <div class="adv-manual-wrap ${!isManual?'hidden':''}">
        <div class="adlink-wrap">
          <input class="kw-inp adv-manual-name" type="text" placeholder="광고주명" value="${esc(isManual ? displayAdv : '')}"/>
          <input class="kw-inp mono adv-manual-id" type="text" placeholder="광고계정 ID (숫자)" value="${esc(isManual ? item.linkedAccountId : '')}" style="width:110px;flex-shrink:0"/>
          <button class="btn-adcenter btn-manual-adcenter" ${adUrl && isManual ? `data-url="${esc(adUrl)}"` : 'disabled'} title="광고주센터 열기">🏢</button>
        </div>
      </div>
    </div>

    <!-- ② 키워드 + URL -->
    <div class="kw-main">
      <div class="kw-row"><span class="kw-row-lbl">KW</span><input class="kw-inp kw-inp-kw" type="text" placeholder="예: 고양이분양" value="${esc(item.keyword)}"/></div>
      <div class="kw-row"><span class="kw-row-lbl">URL</span><input class="kw-inp kw-inp-url mono" type="text" placeholder="dogmaru.co.kr" value="${esc(item.url)}"/></div>
    </div>

    <!-- ③ 하단: 목표순위 + 순위결과 + 검색 -->
    <div class="kw-bottom">
      <div class="tgt-wrap">
        <span class="tgt-lbl">목표</span>
        <input class="tgt-inp" type="number" min="1" max="15" value="${item.targetRank||3}"/>
        <span class="tgt-lbl">위</span>
      </div>
      ${rb}${df}
      ${ts ? `<span class="card-ts">${ts}</span>` : '<span class="gap"></span>'}
      <button class="btn btn-acc btn-sm btn-search-kw">검색</button>
    </div>`;
}

function bindKwCardEvents(card, idx) {
  // 기본 입력
  card.querySelector('.kw-inp-kw').addEventListener('change',  e => { kws[idx].keyword   = e.target.value.trim(); });
  card.querySelector('.kw-inp-url').addEventListener('change', e => { kws[idx].url        = e.target.value.trim(); });
  card.querySelector('.tgt-inp').addEventListener('change',    e => { kws[idx].targetRank = parseInt(e.target.value)||3; });
  card.querySelector('.cb-pl').addEventListener('change',  e => { kws[idx].usePowerlink = e.target.checked; });
  card.querySelector('.cb-mob').addEventListener('change', e => { kws[idx].useMobile    = e.target.checked; });

  // ── 드롭다운/수동 모드 전환 ──
  const dropWrap   = card.querySelector('.adv-dropdown-wrap');
  const manualWrap = card.querySelector('.adv-manual-wrap');

  function isManualMode() { return !dropWrap || dropWrap.classList.contains('hidden'); }

  function updateAdcenterBtn() {
    let accountId = '';
    if (isManualMode()) {
      accountId = card.querySelector('.adv-manual-id')?.value.trim() || '';
    } else {
      accountId = card.querySelector('.adlink-sel')?.value || '';
    }
    const url = buildAdCenterUrlDirect(accountId);
    // 모든 🏢 버튼 업데이트
    card.querySelectorAll('.btn-adcenter, .btn-manual-adcenter').forEach(btn => {
      if (url) { btn.dataset.url = url; btn.disabled = false; }
      else     { delete btn.dataset.url; btn.disabled = true; }
    });
    return accountId;
  }

  card.querySelectorAll('.btn-adv-mode').forEach(btn => {
    btn.addEventListener('click', () => {
      card.querySelectorAll('.btn-adv-mode').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const isManual = btn.dataset.mode === 'manual';
      dropWrap.classList.toggle('hidden', isManual);
      manualWrap.classList.toggle('hidden', !isManual);
      // 모드 전환 시 linkedAccountId 초기화
      kws[idx].linkedAccountId = '';
      kws[idx].advertiser      = '';
      updateAdcenterBtn();
    });
  });

  // ── 드롭다운 변경 ──
  const selAdl = card.querySelector('.adlink-sel');
  if (selAdl) {
    selAdl.addEventListener('change', () => {
      kws[idx].linkedAccountId = selAdl.value;
      const acc = navAccounts.find(a => a.accountId === selAdl.value);
      kws[idx].advertiser = acc ? (acc.advertiser||acc.name) : '';
      updateAdcenterBtn();
    });
  }

  // ── 수동 입력 변경 ──
  const manualName = card.querySelector('.adv-manual-name');
  const manualId   = card.querySelector('.adv-manual-id');
  if (manualName) manualName.addEventListener('change', e => { kws[idx].advertiser = e.target.value.trim(); });
  if (manualId)   manualId.addEventListener('change',   e => {
    kws[idx].linkedAccountId = e.target.value.trim();
    updateAdcenterBtn();
  });
  if (manualId)   manualId.addEventListener('input', updateAdcenterBtn);

  // ── 광고주센터 클릭 ──
  card.querySelectorAll('.btn-adcenter, .btn-manual-adcenter').forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.url) chrome.tabs.create({ url: btn.dataset.url });
      else toast('관리계정 ID를 먼저 설정하세요 (광고주 탭 → ⚙️)');
    });
  });

  // ── 검색 ──
  card.querySelector('.btn-search-kw').addEventListener('click', () => {
    const k = kws[idx];
    if (!k.keyword.trim()) { toast('키워드를 입력하세요'); return; }
    chrome.tabs.create({ url: naverSearchUrl(k.keyword, k.usePowerlink, k.useMobile) });
  });

  // ── 삭제 ──
  card.querySelector('.btn-del').addEventListener('click', () => {
    kws.splice(idx, 1); saveKw(); renderKw(); toast('삭제되었습니다');
  });
}

function rankBadgeHTML(lastRank, st) {
  const cls = { better:'rb rb-better', good:'rb rb-good', bad:'rb rb-bad', miss:'rb rb-miss', none:'rb rb-none' };
  const c = cls[st] || 'rb rb-none';
  if (st === 'none') return `<span class="${c}">미확인</span>`;
  if (st === 'miss') return `<span class="${c}">미노출</span>`;
  return `<span class="${c}">${lastRank}위</span>`;
}
function diffHTML(d) {
  return d==='▲' ? '<span class="diff-u">▲</span>' : d==='▼' ? '<span class="diff-d">▼</span>' : '<span class="diff-s">—</span>';
}

function saveAllKw() {
  document.querySelectorAll('.kw-card').forEach((card, idx) => {
    if (!kws[idx]) return;
    const kw      = card.querySelector('.kw-inp-kw');
    const url     = card.querySelector('.kw-inp-url');
    const tgt     = card.querySelector('.tgt-inp');
    const pl      = card.querySelector('.cb-pl');
    const mob     = card.querySelector('.cb-mob');
    const dropWrap   = card.querySelector('.adv-dropdown-wrap');
    const isManual   = dropWrap?.classList.contains('hidden');
    if (kw)  kws[idx].keyword      = kw.value.trim();
    if (url) kws[idx].url          = url.value.trim();
    if (tgt) kws[idx].targetRank   = parseInt(tgt.value)||3;
    if (pl)  kws[idx].usePowerlink = pl.checked;
    if (mob) kws[idx].useMobile    = mob.checked;
    if (isManual) {
      const mn = card.querySelector('.adv-manual-name');
      const mi = card.querySelector('.adv-manual-id');
      if (mn) kws[idx].advertiser      = mn.value.trim();
      if (mi) kws[idx].linkedAccountId = mi.value.trim();
    } else {
      const sel = card.querySelector('.adlink-sel');
      if (sel) {
        kws[idx].linkedAccountId = sel.value;
        const acc = navAccounts.find(a => a.accountId === sel.value);
        if (acc) kws[idx].advertiser = acc.advertiser||acc.name;
      }
    }
  });
  saveKw(); renderKw(); toast('저장되었습니다 ✓'); refreshTs();
}
function saveKw()    { chrome.storage.local.set({ [KW_SK]: kws }); }
function refreshTs() { document.getElementById('savedTs').textContent = '저장: ' + new Date().toLocaleTimeString('ko-KR', { hour:'2-digit', minute:'2-digit' }); }

function downloadCSV() {
  if (!kws.length) { toast('저장된 키워드가 없습니다'); return; }
  const BOM  = '\uFEFF';
  const head = ['업체명','키워드','표시 도메인','목표 순위','더보기','모바일','연결 계정ID','현재 순위','순위 변동','마지막 확인'];
  const rows = kws.map(k => [
    k.advertiser||'', k.keyword, k.url, k.targetRank??'',
    k.usePowerlink ? 'Y' : 'N',
    k.useMobile    ? 'Y' : 'N',
    k.linkedAccountId||'',
    k.lastRank??(k.lastCheckedAt?'미노출':''), k.diff||'-',
    k.lastCheckedAt ? new Date(k.lastCheckedAt).toLocaleString('ko-KR') : ''
  ].map(v => `"${String(v).replace(/"/g,'""')}"`).join(','));
  const csv  = BOM + [head.join(','), ...rows].join('\r\n');
  const blob = new Blob([csv], { type:'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href=url; a.download=`파워링크순위_${new Date().toISOString().slice(0,10)}.csv`;
  a.click(); URL.revokeObjectURL(url);
  toast('키워드 CSV 다운로드 완료');
}

function downloadNavCSV() {
  if (!navAccounts.length) { toast('저장된 광고주 계정이 없습니다'); return; }
  const BOM  = '\uFEFF';
  const head = ['계정명','광고계정 ID','관리계정 ID','광고주명','에이전트명','태그','등록일'];
  const rows = navAccounts.map(a => [
    a.name||'', a.accountId||'', a.managerAccountId||'',
    a.advertiser||'', a.agentName||'',
    (a.tags||[]).join('|'),
    a.createdAt ? new Date(a.createdAt).toLocaleString('ko-KR') : ''
  ].map(v => `"${String(v).replace(/"/g,'""')}"`).join(','));
  const csv  = BOM + [head.join(','), ...rows].join('\r\n');
  const blob = new Blob([csv], { type:'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href=url; a.download=`광고주계정_${new Date().toISOString().slice(0,10)}.csv`;
  a.click(); URL.revokeObjectURL(url);
  toast('광고주 CSV 다운로드 완료');
}

/* ══════════════════════════════════════
   ② 광고주 패널
══════════════════════════════════════ */
function initNavPanel() {
  const navSearchEl = document.getElementById('navSearch');
  const navSearchClear = document.getElementById('navSearchClear');

  navSearchEl.addEventListener('input', e => {
    navQuery = e.target.value;
    navSearchClear.style.display = navQuery ? 'flex' : 'none';
    renderNav();
  });
  navSearchEl.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      navSearchEl.value = '';
      navQuery = '';
      navSearchClear.style.display = 'none';
      renderNav();
      navSearchEl.blur();
    }
  });
  navSearchClear.addEventListener('click', () => {
    navSearchEl.value = '';
    navQuery = '';
    navSearchClear.style.display = 'none';
    renderNav();
    navSearchEl.focus();
  });

  document.getElementById('btnNavAdd').addEventListener('click', () => openNavEditModal(null));
  document.getElementById('btnNavCSV').addEventListener('click', downloadNavCSV);
  document.getElementById('btnNavSettings').addEventListener('click', () => {
    document.getElementById('setupMgrId').value   = config?.managerAccountId || '';
    document.getElementById('setupDivName').value = config?.divisionName || '';
    showSetup();
  });

  document.getElementById('btnNavPaste').addEventListener('click', () => {
    navPasteRows = [];
    document.getElementById('navPasteTa').value = '';
    document.getElementById('navPasteOk').classList.remove('show');
    document.getElementById('navPasteErr').classList.remove('show');
    document.getElementById('navPastePreviewWrap').style.display = 'none';
    document.getElementById('navPasteStatus').textContent = '계정 목록을 붙여넣으세요';
    document.getElementById('navPasteConfirm').disabled = true;
    openModal('navPasteModal');
    setTimeout(() => document.getElementById('navPasteTa').focus(), 100);
  });

  const pta = document.getElementById('navPasteTa');
  pta.addEventListener('input', () => parseNavPaste(pta.value));
  pta.addEventListener('paste', () => setTimeout(() => parseNavPaste(pta.value), 30));

  document.getElementById('navPasteConfirm').addEventListener('click', handleNavPasteConfirm);

  // 모달 저장
  document.getElementById('navEditSave').addEventListener('click', handleNavEditSave);
  ['navEditName','navEditAccountId','navEditManagerId','navEditAdvertiser','navEditAgent','navEditTags']
    .forEach(id => document.getElementById(id)?.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); handleNavEditSave(); }
    }));

  // 태그 프리셋
  document.querySelectorAll('.tag-preset').forEach(btn => {
    btn.addEventListener('click', () => {
      const inp = document.getElementById('navEditTags');
      const cur = inp.value.split(',').map(t => t.trim()).filter(Boolean);
      const tag = btn.dataset.tag;
      if (!cur.includes(tag)) inp.value = cur.length ? cur.join(', ') + ', ' + tag : tag;
    });
  });
}

/* ── 광고주 렌더 — 소속 에이전트별 그룹 ── */
function renderNav() {
  const list = document.getElementById('navList');
  document.getElementById('navCount').textContent = `${navAccounts.length}개`;

  // navList 내용 초기화 (navEmpty는 navList 밖이므로 안전)
  list.innerHTML = '';
  const navEmpty = document.getElementById('navEmpty');

  if (!navAccounts.length) {
    navEmpty.style.display = 'flex';
    list.innerHTML = '';
    return;
  }

  // 검색 필터 — 부분 포함
  const rawQ = (navQuery || '').trim();
  const q    = rawQ.toLowerCase();
  let filtered = [...navAccounts];
  if (q) {
    filtered = filtered.filter(a =>
      (a.name        ||'').toLowerCase().includes(q) ||
      (a.accountId   ||'').toLowerCase().includes(q) ||
      (a.advertiser  ||'').toLowerCase().includes(q) ||
      (a.agentName   ||'').toLowerCase().includes(q) ||
      (a.managerName ||'').toLowerCase().includes(q) ||
      (a.tags||[]).some(t => t.toLowerCase().includes(q))
    );
  }

  // 검색 결과 없음
  if (!filtered.length) {
    navEmpty.style.display = 'none';
    const noResult = document.createElement('div');
    noResult.className = 'empty-state';
    noResult.innerHTML = `<div class="ei">🔍</div><div class="et">검색 결과 없음</div><div class="es">"${esc(rawQ)}"을 포함하는 계정이 없습니다.<br>검색창을 지우면 전체 목록이 표시됩니다.</div>`;
    list.appendChild(noResult);
    return;
  }

  navEmpty.style.display = 'none';
  const recentIds = new Set(navRecent.slice(0, 5).map(r => r.id));

  // 즐겨찾기 최상단
  const favAccounts  = filtered.filter(a => navFavs.includes(a.id));
  const restAccounts = filtered.filter(a => !navFavs.includes(a.id));

  // 소속 에이전트(agentName)별 그룹핑
  const groups = {};
  restAccounts.forEach(a => {
    const key = (a.agentName||'').trim() || '미지정';
    if (!groups[key]) groups[key] = [];
    groups[key].push(a);
  });

  if (favAccounts.length) {
    appendNavGroup(list, `⭐ 즐겨찾기`, favAccounts, recentIds, q);
  }

  const sortedAgents = Object.keys(groups).sort((a, b) => {
    if (a === '미지정') return 1;
    if (b === '미지정') return -1;
    return a.localeCompare(b, 'ko');
  });
  sortedAgents.forEach(agent => {
    appendNavGroup(list, `👤 ${agent} (${groups[agent].length}개)`, groups[agent], recentIds, q);
  });
  collapsedInitialized = true; // 이후부터는 사용자가 토글한 상태 유지
}

// 접힌 그룹 상태 저장 (기본값: 접힘)
const collapsedGroups = new Set();
let collapsedInitialized = false;

function appendNavGroup(list, groupName, accounts, recentIds, q) {
  const groupKey = groupName;
  // 첫 렌더 시 모든 그룹 기본 접힘 처리
  if (!collapsedInitialized) collapsedGroups.add(groupKey);
  const isCollapsed = collapsedGroups.has(groupKey);

  // 그룹 헤더
  const hdr = document.createElement('div');
  hdr.className = 'nav-group-hdr' + (isCollapsed ? ' collapsed' : '');
  hdr.innerHTML = `<span class="nav-group-name">${esc(groupName)}</span><span class="nav-group-toggle">${isCollapsed ? '▶' : '▼'}</span>`;
  hdr.addEventListener('click', () => {
    if (collapsedGroups.has(groupKey)) collapsedGroups.delete(groupKey);
    else collapsedGroups.add(groupKey);
    renderNav();
  });
  list.appendChild(hdr);

  if (isCollapsed) return; // 접혀있으면 카드 렌더 스킵

  accounts.forEach(acc => {
    const card = document.createElement('div');
    const isFav    = navFavs.includes(acc.id);
    const isRecent = recentIds.has(acc.id);
    card.className = `nav-card${isFav ? ' fav' : ''}`;

    const hl = txt => {
      if (!q || !txt) return esc(txt||'');
      return esc(txt).replace(new RegExp(`(${escReg(q)})`, 'gi'), '<mark>$1</mark>');
    };

    const tagHtml = (acc.tags||[]).map(t => {
      const cls = t==='VIP'?'vip':t==='위험'?'danger':t==='신규'?'new':t==='휴면'?'dormant':'';
      return `<span class="nav-tag ${cls}">${esc(t)}</span>`;
    }).join('');

    card.innerHTML = `
      <div class="nav-name">
        ${isRecent ? '<span class="recent-dot"></span>' : ''}
        ${hl(acc.name)}
        ${isFav ? '⭐' : ''}
      </div>
      ${acc.advertiser && acc.advertiser !== acc.name ? `<div class="nav-advertiser">${hl(acc.advertiser)}</div>` : ''}
      <div class="nav-id">
        <span>${hl(acc.accountId)}</span>
        ${acc.agentName ? `<span>· ${hl(acc.agentName)}</span>` : ''}
        ${tagHtml}
      </div>
      <div class="nav-actions">
        <button class="nav-action-btn fav-btn ${isFav?'active':''}" title="${isFav?'즐겨찾기 해제':'즐겨찾기 추가'}">☆</button>
        <button class="nav-action-btn edit-btn" title="수정">✏️</button>
        <button class="nav-action-btn del-btn" title="삭제">🗑</button>
      </div>`;

    // 클릭 → 광고주센터
    card.addEventListener('click', async e => {
      if (e.target.closest('.nav-action-btn')) return;
      const url = buildAdCenterUrl(acc.accountId);
      if (!url) { toast('관리계정 ID를 먼저 설정하세요 (⚙️ 버튼)'); return; }
      await addNavRecent(acc.id);
      chrome.tabs.create({ url });
    });

    card.querySelector('.fav-btn').addEventListener('click', async e => {
      e.stopPropagation();
      const i = navFavs.indexOf(acc.id);
      if (i === -1) navFavs.push(acc.id); else navFavs.splice(i, 1);
      await chrome.storage.local.set({ [NAV_FAV]: navFavs });
      renderNav();
    });

    card.querySelector('.edit-btn').addEventListener('click', e => {
      e.stopPropagation(); openNavEditModal(acc.id);
    });

    card.querySelector('.del-btn').addEventListener('click', async e => {
      e.stopPropagation();
      if (!confirm(`"${acc.name}" 계정을 삭제하시겠습니까?`)) return;
      navAccounts = navAccounts.filter(a => a.id !== acc.id);
      navFavs     = navFavs.filter(id => id !== acc.id);
      await chrome.storage.local.set({ [NAV_SK]: navAccounts, [NAV_FAV]: navFavs });
      renderNav(); renderKw(); toast('계정이 삭제되었습니다');
    });

    list.appendChild(card);
  });
}

async function addNavRecent(id) {
  navRecent = navRecent.filter(r => r.id !== id);
  navRecent.unshift({ id, visitedAt: new Date().toISOString() });
  navRecent = navRecent.slice(0, 10);
  await chrome.storage.local.set({ [NAV_REC]: navRecent });
}

/* ── 광고주 추가/수정 모달 ── */
function openNavEditModal(id) {
  navEditingId = id;
  document.getElementById('navEditTitle').textContent = id ? '계정 수정' : '계정 추가';
  document.getElementById('navEditErr').style.display = 'none';
  if (id) {
    const acc = navAccounts.find(a => a.id === id);
    if (!acc) return;
    document.getElementById('navEditName').value       = acc.name||'';
    document.getElementById('navEditAccountId').value  = acc.accountId||'';
    document.getElementById('navEditManagerId').value  = acc.managerAccountId||'';
    document.getElementById('navEditAdvertiser').value = acc.advertiser||'';
    document.getElementById('navEditAgent').value      = acc.agentName||'';
    document.getElementById('navEditTags').value       = (acc.tags||[]).join(', ');
  } else {
    ['navEditName','navEditAccountId','navEditManagerId','navEditAdvertiser','navEditAgent','navEditTags']
      .forEach(id => { document.getElementById(id).value = ''; });
  }
  openModal('navEditModal');
  setTimeout(() => document.getElementById('navEditName').focus(), 100);
}

async function handleNavEditSave() {
  const name       = document.getElementById('navEditName').value.trim();
  const accountId  = document.getElementById('navEditAccountId').value.trim();
  const managerId  = document.getElementById('navEditManagerId').value.trim();
  const advertiser = document.getElementById('navEditAdvertiser').value.trim();
  const agentName  = document.getElementById('navEditAgent').value.trim();
  const tagsRaw    = document.getElementById('navEditTags').value.trim();
  const tags       = tagsRaw ? tagsRaw.split(',').map(t => t.trim()).filter(Boolean) : [];

  if (!name || !accountId) { document.getElementById('navEditErr').style.display = 'block'; return; }

  if (navEditingId) {
    const idx = navAccounts.findIndex(a => a.id === navEditingId);
    if (idx !== -1) navAccounts[idx] = { ...navAccounts[idx], name, accountId, managerAccountId:managerId, advertiser:advertiser||name, agentName, tags };
    toast('계정이 수정되었습니다');
  } else {
    navAccounts.push({ id:uid(), name, accountId, managerAccountId:managerId, advertiser:advertiser||name, agentName, agentId:'', tags, createdAt:new Date().toISOString() });
    toast('계정이 추가되었습니다');
  }
  _navSkipNextChange = true;
  await chrome.storage.local.set({ [NAV_SK]: navAccounts });
  closeModal('navEditModal');
  renderNav(); renderKw();
}

/* ── 붙여넣기 파싱 (네이버 광고 관리 시스템 TSV) ── */
function parseNavPaste(raw) {
  navPasteRows = [];
  const lines = raw.trim().split(/\r?\n/);
  if (lines.length < 2) { showNavPasteResult([], 0); return; }

  const firstLine = lines[0];
  const tabCount  = (firstLine.match(/\t/g)||[]).length;
  const commaCount= (firstLine.match(/,/g) ||[]).length;
  const delimiter = tabCount >= commaCount ? '\t' : ',';

  const splitLine = line => delimiter === '\t'
    ? line.split('\t').map(c => c.trim().replace(/^"|"$/g,''))
    : parseCSVLine(line);

  const rawHeader = splitLine(lines[0]).map(h => h.replace(/^\uFEFF/,'').trim().toLowerCase());
  const findCol   = (...kws) => { for (const kw of kws) { const i = rawHeader.findIndex(h => h.includes(kw)); if (i !== -1) return i; } return -1; };

  const COL = {
    accountId:       findCol('담당 광고 계정 id', '광고 계정 id', '계정id', 'accountid'),
    name:            findCol('담당 광고 계정 이름', '광고 계정 이름', '계정명', '계정 이름'),
    managerAccountId:findCol('소속 관리 계정 id', '관리 계정 id', '관리계정id', 'managerid'),
    managerName:     findCol('소속 관리 계정 이름', '관리 계정 이름', '관리계정명'),
    agentName:       findCol('담당 에이전트 이름', '에이전트 이름', '에이전트명'),
    agentId:         findCol('담당 에이전트 id', '에이전트 id', '에이전트id'),
    advertiser:      findCol('광고주명', '광고주'),
    tags:            findCol('태그', 'tag'),
  };

  if (COL.accountId === -1) { showNavPasteResult([], 0); return; }

  const parsed = [];
  for (let i = 1; i < lines.length; i++) {
    if (!lines[i].trim()) continue;
    const cols = splitLine(lines[i]);
    const get  = idx => idx !== -1 ? (cols[idx]||'').trim() : '';
    const accountId = get(COL.accountId);
    if (!accountId) continue;
    const name = get(COL.name) || accountId;
    // 담당 에이전트 이름은 마스킹(*포함)이므로 소속 관리 계정 이름으로 대체
    const rawAgentName  = get(COL.agentName);
    const rawManagerName = get(COL.managerName);
    // agentName에 * 있으면 마스킹된 상위계정명 → managerName으로 대체
    const displayAgent  = rawAgentName.includes('*') ? rawManagerName : rawAgentName;

    parsed.push({
      id: Date.now().toString() + i,
      name, accountId,
      managerAccountId: get(COL.managerAccountId), // 저장은 하되 URL에는 미사용
      advertiser:       get(COL.advertiser) || name,
      agentName:        displayAgent,   // 마스킹 → 소속 관리 계정 이름으로 대체
      agentId:          get(COL.agentId), // 내부 ID, UI에서 숨김
      managerName:      rawManagerName,
      tags:             get(COL.tags) ? get(COL.tags).split('|').map(t=>t.trim()).filter(Boolean) : [],
      createdAt:        new Date().toISOString(),
    });
  }

  navPasteRows = parsed;
  showNavPasteResult(parsed, 0);
}

function showNavPasteResult(rows, dupCount) {
  const ok  = document.getElementById('navPasteOk');
  const err = document.getElementById('navPasteErr');
  const st  = document.getElementById('navPasteStatus');
  const btn = document.getElementById('navPasteConfirm');
  const prv = document.getElementById('navPastePreviewWrap');
  const tbl = document.getElementById('navPastePreview');

  if (rows.length) {
    ok.textContent = `✅ ${rows.length}개 계정 인식됨`;
    ok.classList.add('show'); err.classList.remove('show');
    st.textContent = `${rows.length}개 계정을 가져옵니다`;
    btn.disabled = false;

    const sample = rows.slice(0, 5);
    tbl.innerHTML = `<thead><tr><th>계정명</th><th>광고계정 ID</th><th>관리계정 ID</th><th>에이전트</th></tr></thead>
      <tbody>${sample.map(a => `<tr><td>${esc(a.name)}</td><td>${esc(a.accountId)}</td><td>${esc(a.managerAccountId||'-')}</td><td>${esc(a.agentName||'-')}</td></tr>`).join('')}</tbody>`;
    if (rows.length > 5) {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td colspan="4" style="color:var(--txt3);font-style:italic">... 외 ${rows.length-5}개</td>`;
      tbl.querySelector('tbody').appendChild(tr);
    }
    prv.style.display = 'block';
  } else {
    ok.classList.remove('show');
    err.textContent = '인식된 계정이 없습니다. 헤더(담당 광고 계정 ID 등)를 포함해서 붙여넣으세요.';
    err.classList.add('show');
    prv.style.display = 'none';
    st.textContent = '계정 목록을 붙여넣으세요';
    btn.disabled = true;
  }
}

async function handleNavPasteConfirm() {
  if (!navPasteRows.length) return;
  const existingIds = new Set(navAccounts.map(a => a.accountId));
  const newRows = navPasteRows.filter(a => !existingIds.has(a.accountId));
  const dup     = navPasteRows.length - newRows.length;
  if (!newRows.length) { toast('모두 이미 등록된 계정입니다'); closeModal('navPasteModal'); return; }

  navAccounts = [...navAccounts, ...newRows];
  _navSkipNextChange = true; // storage.onChanged 중복 렌더 방지
  await chrome.storage.local.set({ [NAV_SK]: navAccounts });
  closeModal('navPasteModal');
  navQuery = ''; // 검색 초기화
  document.getElementById('navSearch').value = '';
  renderNav(); renderKw();
  toast(`${newRows.length}개 추가${dup > 0 ? ` (중복 ${dup}개 제외)` : ''}`);
}

function parseCSVLine(line) {
  const result = []; let cur = '', inQ = false;
  for (const ch of line) {
    if (ch === '"') { inQ = !inQ; }
    else if (ch === ',' && !inQ) { result.push(cur.trim()); cur = ''; }
    else cur += ch;
  }
  result.push(cur.trim()); return result;
}

/* ══════════════════════════════════════
   ③ 스캔 패널
══════════════════════════════════════ */
// 탭 로드 완료 시 content.js 강제 주입 (모바일/더보기 지면 대비)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!openTabMap[String(tabId)]) return; // 스캔 탭이 아니면 무시

  const SCAN_DOMAINS = [
    'search.naver.com', 'ad.search.naver.com',
    'm.search.naver.com', 'm.ad.search.naver.com'
  ];
  const isNaverSearch = SCAN_DOMAINS.some(d => (tab.url||'').includes(d));
  if (!isNaverSearch) return;

  // content.js 재주입 (이미 실행 중이면 window.__plrank3__ 가드로 무시됨)
  chrome.scripting.executeScript({
    target: { tabId },
    files: ['content.js'],
  }).catch(() => { /* 이미 주입됐거나 권한 없음 — 무시 */ });
});

function initScanPanel() {
  document.getElementById('btnScanAll').addEventListener('click', () => {
    scanActive ? stopScan() : startFullScan();
  });
  document.getElementById('advFilter').addEventListener('click', e => {
    const chip = e.target.closest('.adv-chip');
    if (chip) {
      activeAdv = chip.dataset.adv;
      document.querySelectorAll('.adv-chip').forEach(c => c.classList.toggle('active', c.dataset.adv === activeAdv));
      renderResultCards();
    }
    const rs = e.target.closest('.adv-rescan');
    if (rs) startAdvScan(rs.dataset.adv);
  });
}

async function startFullScan() {
  const valid = kws.filter(k => k.keyword.trim() && k.url.trim());
  if (!valid.length) { toast('키워드와 도메인이 입력된 항목이 없습니다'); return; }
  if (valid.length > 5) {
    toast(`⚠️ 스캔은 최대 5개까지 가능합니다 (현재 ${valid.length}개)`);
    return;
  }
  await beginScan(valid);
}

async function startAdvScan(advName) {
  const valid = kws.filter(k => k.keyword.trim() && k.url.trim() && (k.advertiser||'') === advName);
  if (!valid.length) { toast(`${advName}의 유효 키워드가 없습니다`); return; }
  if (valid.length > 5) {
    toast(`⚠️ 스캔은 최대 5개까지 가능합니다 (현재 ${valid.length}개)`);
    return;
  }
  await beginScan(valid);
}

async function beginScan(items) {
  if (scanActive) return;
  scanActive=true; scanTotal=items.length; scanDone=0;
  openTabMap={}; scanResults=[]; activeAdv='__all__';

  await chrome.storage.local.set({ __plrank_scan_tabs__: {} });
  switchTab('scan');
  document.getElementById('scanEmpty').style.display = 'none';
  document.getElementById('resultSummary').style.display = 'none';
  document.getElementById('resultList').innerHTML = '';
  document.getElementById('advFilter').style.display = 'none';

  setScanState('running', `0 / ${scanTotal} 스캔 중...`);
  const btn = document.getElementById('btnScanAll');
  btn.textContent = '⏹ 중지'; btn.className = 'btn btn-o btn-sm';

  const BATCH = 5, DELAY = 2000; // 간격 늘려서 동일 키워드 탭 충돌 방지
  // 같은 키워드가 여러 지면으로 등록된 경우 순서 분리 (PC 먼저, 모바일 나중)
  items.sort((a, b) => {
    if (a.keyword !== b.keyword) return 0;
    // 같은 키워드면 PC(useMobile=false)를 앞으로
    return (a.useMobile ? 1 : 0) - (b.useMobile ? 1 : 0);
  });
  for (let i = 0; i < items.length && scanActive; i += BATCH) {
    await Promise.all(items.slice(i, i+BATCH).map(async item => {
      const tab = await chrome.tabs.create({
        url: naverSearchUrl(item.keyword, item.usePowerlink||false, item.useMobile||false),
        active: false
      });
      openTabMap[String(tab.id)] = { keyword: item.keyword, itemId: item.id };
    }));

    // scanTabs: tabId → keyword (content.js 자동스캔 판별용)
    const scanTabsForStorage = {};
    Object.entries(openTabMap).forEach(([tid, v]) => {
      scanTabsForStorage[tid] = typeof v === 'string' ? v : v.keyword;
    });
    await chrome.storage.local.set({ __plrank_scan_tabs__: scanTabsForStorage });
    if (i + BATCH < items.length) await sleep(DELAY);
  }

  // 탭별 타임아웃: 15초 안에 완료 신호 없으면 강제로 탭 닫고 카운트
  // (모바일/더보기 지면에서 content.js 로드 실패 시 대비)
  scheduleTabTimeouts();
}

function scheduleTabTimeouts() {
  const TIMEOUT_MS = 5000;
  Object.keys(openTabMap).forEach(tid => {
    setTimeout(async () => {
      if (!openTabMap[tid]) return; // 이미 닫힘
      console.warn('[PLR] 타임아웃 — 강제 닫기:', tid, openTabMap[tid]);
      const v   = openTabMap[tid];
      const kw  = typeof v === 'string' ? v : v?.keyword;
      const numTid = Number(tid);
      if (!isNaN(numTid)) { try { await chrome.tabs.remove(numTid); } catch { /**/ } }
      delete openTabMap[tid];

      // 해당 키워드 최신 데이터로 결과에 추가 (순위 미확인 상태로)
      if (scanActive) {
        const fr = await chrome.storage.local.get(KW_SK);
        const fk = fr[KW_SK] || [];
        fk.filter(k => k.keyword.trim().toLowerCase() === (kw||'').trim().toLowerCase())
          .forEach(item => {
            const resIdx = scanResults.findIndex(r =>
              r.itemId === item.id ||
              (r.keyword === item.keyword &&
               r.usePowerlink === (item.usePowerlink||false) &&
               r.useMobile    === (item.useMobile||false))
            );
            if (resIdx === -1) {
              scanResults.push({
                itemId: item.id, keyword: item.keyword, advertiser: item.advertiser||'',
                url: item.url||'', currentRank: null,
                targetRank: item.targetRank||3, diff: '-',
                usePowerlink: item.usePowerlink||false, useMobile: item.useMobile||false,
                linkedAccountId: item.linkedAccountId||'',
              });
            }
          });

        scanDone++;
        updateScanProgress();
        renderResultCards();
        updateAdvFilter();

        const scanTabsForStorage = {};
        Object.entries(openTabMap).forEach(([t, v2]) => {
          scanTabsForStorage[t] = typeof v2 === 'string' ? v2 : v2.keyword;
        });
        await chrome.storage.local.set({ __plrank_scan_tabs__: scanTabsForStorage });
        if (scanDone >= scanTotal) finishScan();
      }
    }, TIMEOUT_MS);
  });
}

function stopScan() {
  Object.keys(openTabMap).forEach(tid => {
    const numTid = Number(tid);
    if (!isNaN(numTid)) { try { chrome.tabs.remove(numTid); } catch { /**/ } }
  });
  openTabMap={}; scanActive=false;
  chrome.storage.local.set({ __plrank_scan_tabs__: {} });
  setScanState('ready'); resetScanBtn();
}

function updateScanProgress() {
  const pct = Math.round(scanDone / scanTotal * 100);
  document.getElementById('scanProgBar').style.width = pct + '%';
  setScanState('running', `${scanDone} / ${scanTotal} 완료`);
  const badge = document.getElementById('scanBadge');
  badge.textContent = scanDone; badge.classList.add('show');
}

function finishScan() {
  scanActive = false;
  chrome.storage.local.set({ __plrank_scan_tabs__: {} });
  setScanState('done', `${scanTotal}개 스캔 완료`);
  resetScanBtn(); renderSummary();
  toast(`${scanTotal}개 키워드 스캔 완료 ✓`);
  sendScanNotification();
}

function resetScanBtn() {
  const btn = document.getElementById('btnScanAll');
  btn.textContent = '🚀 전체 스캔'; btn.className = 'btn btn-scan btn-sm';
}

/* ══════════════════════════════════════
   Chrome 알림 — 스캔 완료 후 미달/미노출 알림
══════════════════════════════════════ */
function sendScanNotification() {
  const bad  = scanResults.filter(r => rankSt(r.currentRank, true, r.targetRank) === 'bad');
  const miss = scanResults.filter(r => r.currentRank === null);
  const good = scanResults.filter(r => ['better','good'].includes(rankSt(r.currentRank, true, r.targetRank)));

  const total     = scanResults.length;
  const alertCount = bad.length + miss.length;

  // 알림 메시지 구성
  let title, message, iconType;

  if (alertCount === 0) {
    // 전체 달성/초과 — 축하 알림
    title   = `✅ 전체 목표 달성! (${total}개)`;
    message = `모든 키워드가 목표 순위 이내입니다.`;
    iconType = 'good';
  } else {
    // 미달/미노출 항목 있음 — 경고 알림
    const parts = [];
    if (miss.length) parts.push(`미노출 ${miss.length}개`);
    if (bad.length)  parts.push(`순위 미달 ${bad.length}개`);

    title   = `⚠️ 확인 필요 (${alertCount}/${total}개)`;

    // 미달 항목 최대 3개 나열
    const alertItems = [...miss, ...bad].slice(0, 3);
    const itemLines  = alertItems.map(r => {
      const st = r.currentRank === null ? '미노출' : `${r.currentRank}위 (목표${r.targetRank}위)`;
      const adv = r.advertiser ? `[${r.advertiser}] ` : '';
      return `${adv}${r.keyword}: ${st}`;
    });
    if (alertCount > 3) itemLines.push(`외 ${alertCount - 3}개...`);

    message  = itemLines.join('\n');
    iconType = 'bad';
  }

  // Chrome 알림 발송
  chrome.notifications.create(`plrank_scan_${Date.now()}`, {
    type:    'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message,
    priority: alertCount > 0 ? 2 : 1,
  }, id => {
    if (chrome.runtime.lastError) {
      console.warn('[PLR] 알림 오류:', chrome.runtime.lastError.message);
    }
    // 10초 후 자동 닫기 (선택)
    setTimeout(() => chrome.notifications.clear(id, () => {}), 10000);
  });
}

function setScanState(state, sub) {
  const dot  = document.getElementById('scanDot');
  const lbl  = document.getElementById('scanLabel');
  const subEl= document.getElementById('scanSub');
  const pw   = document.getElementById('scanProgWrap');
  dot.className = 'scan-dot' + (state==='running' ? ' running' : state==='done' ? ' done' : '');
  if (state === 'running') {
    lbl.textContent = '🔄 스캔 진행 중'; subEl.textContent = sub||''; pw.style.display = 'block';
  } else if (state === 'done') {
    lbl.textContent = '✅ 스캔 완료'; subEl.textContent = sub||''; pw.style.display = 'block';
    document.getElementById('scanProgBar').style.width = '100%';
  } else {
    lbl.textContent = '준비됨';
    subEl.textContent = '각 키워드의 지면 설정에 따라 검색합니다. 미체크 = PC 통합검색. 탭은 자동으로 닫힙니다.';
    pw.style.display = 'none';
  }
}

function updateAdvFilter() {
  const filter = document.getElementById('advFilter');
  const advs   = [...new Set(scanResults.map(r => r.advertiser||''))].filter(Boolean);
  if (advs.length < 2) { filter.style.display='none'; return; }
  filter.style.display = 'flex';
  filter.innerHTML = `<span class="adv-filter-lbl">업체:</span>`;

  const allBtn = document.createElement('button');
  allBtn.className = `adv-chip${activeAdv==='__all__'?' active':''}`;
  allBtn.dataset.adv = '__all__';
  allBtn.textContent = `전체(${scanResults.length})`;
  filter.appendChild(allBtn);

  advs.sort().forEach(adv => {
    const cnt  = scanResults.filter(r => r.advertiser===adv).length;
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:flex;align-items:center;flex-shrink:0';
    const chip = document.createElement('button');
    chip.className = `adv-chip${activeAdv===adv?' active':''}`;
    chip.style.borderRadius = '20px 0 0 20px';
    chip.dataset.adv = adv; chip.textContent = `${adv}(${cnt})`;
    const rs = document.createElement('button');
    rs.className = 'adv-rescan'; rs.dataset.adv = adv; rs.title = `${adv} 재스캔`; rs.textContent = '↺';
    wrap.appendChild(chip); wrap.appendChild(rs);
    filter.appendChild(wrap);
  });
}

function renderResultCards() {
  const list  = document.getElementById('resultList');
  list.innerHTML = '';
  const items = activeAdv==='__all__' ? scanResults : scanResults.filter(r => r.advertiser===activeAdv);

  items.forEach((r, i) => {
    const st    = rankSt(r.currentRank, true, r.targetRank);
    const clrs  = { better:'#16a34a', good:'#2563eb', bad:'#dc2626', miss:'#d97706' };
    const icons = { better:'🟢', good:'✅', bad:'❌', miss:'⚠️' };
    const clr   = clrs[st]||'#9ba3bc';
    const rtxt  = st==='miss' ? '미노출' : `${r.currentRank}`;
    const icon  = icons[st]||'—';
    const dCls  = r.diff==='▲'?'up':r.diff==='▼'?'dn':'same';
    const dTxt  = r.diff==='▲'?'▲':r.diff==='▼'?'▼':'—';

    // 같은 키워드가 여러 지면으로 등록된 경우 지면 뱃지 표시
    // (지면이 기본값PC라도 다른 지면 결과와 구분을 위해 항상 표시)
    const sfCls = r.useMobile ? 'mob' : r.usePowerlink ? 'pcm' : 'pc';
    const sfLbl = r.useMobile ? '📱 모바일 더보기'
                : r.usePowerlink ? '🖥️ PC 더보기'
                : '🖥️ PC 통합검색';

    const adUrl = buildAdCenterUrl(r.linkedAccountId);
    const hint  = st==='bad'  ? '순위 미달 — 입찰가 확인 권장'
                : st==='miss' ? '미노출 — 광고 상태 확인'
                : st==='better'? '목표 초과 달성 ✓'
                : '목표 달성 ✓';

    const card = document.createElement('div');
    card.className = `res-card ${st}`;
    card.style.animationDelay = `${i*0.04}s`;
    card.innerHTML = `
      <div class="rc-r1">
        ${r.advertiser ? `<span class="rc-adv">${esc(r.advertiser)}</span>` : ''}
        <span class="rc-kw">${icon} ${esc(r.keyword)}</span>
        <span class="rc-sf ${sfCls}">${sfLbl}</span>
      </div>
      <div class="rc-r2">
        <span class="rc-rank" style="color:${clr}">${rtxt}</span>
        ${st!=='miss' ? `<span class="rc-unit" style="color:${clr}">위</span>` : ''}
        <div class="rc-meta">
          <span class="rc-tgt">목표 ${r.targetRank}위</span>
          <span class="rc-url">${esc(r.url)}</span>
        </div>
        <span class="rc-diff ${dCls}">${dTxt}</span>
      </div>
      ${adUrl ? `
      <button class="rc-adcenter" data-url="${esc(adUrl)}">
        🏢 광고주센터 열기
        <span class="rc-adcenter-hint">${hint}</span>
      </button>` : ''}`;

    card.querySelector('.rc-adcenter')?.addEventListener('click', e => {
      chrome.tabs.create({ url: e.currentTarget.dataset.url });
    });

    list.appendChild(card);
  });
}

function renderSummary() {
  const el = document.getElementById('resultSummary');
  el.style.display = 'flex';
  const total  = scanResults.length;
  const better = scanResults.filter(r => rankSt(r.currentRank,true,r.targetRank)==='better').length;
  const good   = scanResults.filter(r => rankSt(r.currentRank,true,r.targetRank)==='good').length;
  const bad    = scanResults.filter(r => rankSt(r.currentRank,true,r.targetRank)==='bad').length;
  const miss   = scanResults.filter(r => r.currentRank===null).length;
  el.innerHTML = `
    <div class="sum-card"><div class="sum-num" style="color:#1e2540">${total}</div><div class="sum-lbl">전체</div></div>
    <div class="sum-card" style="border-color:var(--grn3)"><div class="sum-num" style="color:var(--grn)">${better}</div><div class="sum-lbl">초과</div></div>
    <div class="sum-card" style="border-color:var(--blue3)"><div class="sum-num" style="color:var(--blue)">${good}</div><div class="sum-lbl">달성</div></div>
    <div class="sum-card" style="border-color:var(--red3)"><div class="sum-num" style="color:var(--red)">${bad}</div><div class="sum-lbl">미달</div></div>
    <div class="sum-card" style="border-color:var(--ylw3)"><div class="sum-num" style="color:var(--ylw)">${miss}</div><div class="sum-lbl">미노출</div></div>`;
}

/* ══════════════════════════════════════
   유틸
══════════════════════════════════════ */
function uid()    { return Date.now().toString(36) + Math.random().toString(36).slice(2,5); }
function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
function esc(s)   { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function escReg(s){ return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 2400);
}
