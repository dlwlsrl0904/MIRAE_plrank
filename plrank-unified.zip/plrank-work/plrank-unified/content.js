/**
 * content.js — 파워링크 순위 체커 v3
 * 지원 지면:
 *   search.naver.com        — PC 통합검색
 *   ad.search.naver.com     — PC 더보기
 *   m.search.naver.com      — 모바일 통합검색
 *   m.ad.search.naver.com   — 모바일 더보기
 */
(function () {
  'use strict';

  if (window.__plrank3__) return;
  window.__plrank3__ = true;

  const SK  = 'plrank_v2';
  const DBG = true;
  const log  = (...a) => DBG && console.log('%c[PLR]', 'color:#2563eb;font-weight:700', ...a);
  const warn = (...a) => DBG && console.warn('%c[PLR]', 'color:#dc2626;font-weight:700', ...a);

  const host          = location.hostname;
  const isMobileAd   = host === 'm.ad.search.naver.com';
  const isMobileMain = host === 'm.search.naver.com';
  const isPCad       = host === 'ad.search.naver.com';
  const isMobile     = isMobileAd || isMobileMain;
  const isAdPage     = isPCad || isMobileAd;

  const params       = new URLSearchParams(location.search);
  const currentQuery = (params.get('query') || '').trim();
  if (!currentQuery) return;
  log('검색어:', currentQuery, '| 지면:', host);

  /* ── 1. 광고 li 수집 ── */
  function collectAdItems() {
    const seen = new Set(), items = [];
    const add = el => { if (el && !seen.has(el)) { seen.add(el); items.push(el); } };

    document.querySelectorAll('cite').forEach(cite => {
      const block = cite.closest('li') || cite.closest('[class*="bx"]') || cite.closest('div[class]');
      if (block) add(block);
    });

    if (!items.length) {
      document.querySelectorAll('.url_txt,[class*="url_txt"],em[class*="url"],span[class*="url"],.link_url')
        .forEach(el => { const b = el.closest('li') || el.closest('div[class]'); if (b) add(b); });
    }

    if (!items.length) {
      const CONTAINERS = [
        '#sp_npad','#splu','#spls','#power_link_top',
        '.ad_area','.lst_ad','[id*="npad"]','[id*="powerlink"]',
        '[data-nclk-area="pad"]','[class*="power_link"]',
      ];
      for (const sel of CONTAINERS) {
        const c = document.querySelector(sel);
        if (!c) continue;
        for (const ul of c.querySelectorAll('ul')) {
          const li = [...ul.children].filter(e => e.tagName === 'LI');
          if (li.length) { li.forEach(add); break; }
        }
        if (items.length) break;
      }
    }

    if (!items.length && isMobileAd) {
      document.querySelectorAll('li').forEach(li => {
        if (li.querySelector('a[href]') && li.textContent.trim().length > 5) add(li);
      });
    }

    if (items.length > 1) {
      items.sort((a, b) => {
        const pos = a.compareDocumentPosition(b);
        return (pos & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1;
      });
    }
    log('광고 블록:', items.length);
    return items;
  }

  /* ── 2. URL 매칭 ── */
  function norm(s) {
    return (s || '').toLowerCase()
      .replace(/^https?:\/\//, '').replace(/^www\./, '')
      .split('?')[0].split('#')[0].replace(/\/+$/, '').trim();
  }

  function extractDisplayUrl(el) {
    const cite = el.querySelector('cite');
    if (cite?.textContent.trim()) return cite.textContent.trim();
    for (const sel of ['.url_txt','[class*="url_txt"]','[class*="display_url"]','em[class*="url"]','.link_url']) {
      const f = el.querySelector(sel);
      if (f?.textContent.trim()) return f.textContent.trim();
    }
    for (const child of el.querySelectorAll('span,em,small')) {
      const t = child.textContent.trim();
      if (t.includes('.') && !t.includes(' ') && t.length <= 60) return t;
    }
    return '';
  }

  function matchUrl(el, target) {
    if (!target?.trim()) return false;
    const t = norm(target);
    if (!t || t.length < 3) return false;
    const display = norm(extractDisplayUrl(el));
    if (display && (display.includes(t) || t.includes(display.split('/')[0]))) return true;
    for (const a of el.querySelectorAll('a[href]')) {
      const href = a.getAttribute('href') || '';
      if (!href || href === '#') continue;
      if (href.includes('nclk') || href.includes('/adclick') || href.includes('clk.naver')) {
        try { for (const v of new URL(a.href).searchParams.values()) if (norm(v).includes(t)) return true; } catch { /**/ }
        if (href.toLowerCase().includes(t)) return true;
      } else if (norm(href).includes(t)) return true;
    }
    if (t.length >= 5 && el.textContent.toLowerCase().includes(t)) return true;
    return false;
  }

  /* ── 3. 하이라이트 ── */
  function highlight(el, rank, targetRank, advertiser) {
    const better = rank < targetRank, good = rank === targetRank;
    const COLOR = better ? '#16a34a' : good ? '#2563eb' : '#dc2626';
    const BG    = better ? 'rgba(22,163,74,.08)' : good ? 'rgba(37,99,235,.08)' : 'rgba(220,38,38,.08)';

    el.style.setProperty('box-shadow',      `0 0 0 2.5px ${COLOR}`, 'important');
    el.style.setProperty('background-color', BG,                     'important');
    el.style.setProperty('border-radius',   '8px',                   'important');
    el.style.setProperty('position',        'relative',              'important');

    [el.querySelector('cite'), el.querySelector('.url_txt'), el.querySelector('[class*="url_txt"]')]
      .filter(Boolean).forEach(urlEl => {
        urlEl.style.setProperty('background',   `${COLOR}28`, 'important');
        urlEl.style.setProperty('color',         COLOR,        'important');
        urlEl.style.setProperty('border-radius','4px',         'important');
        urlEl.style.setProperty('padding',      '1px 5px',     'important');
        urlEl.style.setProperty('font-weight',  '700',         'important');
        urlEl.style.setProperty('box-shadow',   `0 0 0 1.5px ${COLOR}`, 'important');
      });

    if (!el.querySelector('.__plr3b__')) {
      const b = document.createElement('div');
      b.className = '__plr3b__';
      Object.assign(b.style, {
        position:'absolute', top:'6px', right:'8px', zIndex:'2147483646',
        background:COLOR, color:'#fff', fontSize:'11px', fontWeight:'700',
        padding:'2px 10px', borderRadius:'20px',
        fontFamily:"'Noto Sans KR',sans-serif",
        pointerEvents:'none', whiteSpace:'nowrap', lineHeight:'1.7',
        boxShadow:`0 2px 8px ${COLOR}66`,
      });
      const surf = isMobileAd ? '📱' : isPCad ? '🖥️더보기' : '';
      b.textContent = `${surf ? surf+' ' : ''}📍 ${advertiser || '내 광고'} · ${rank}위`;
      el.appendChild(b);
    }
    setTimeout(() => el.scrollIntoView({ behavior:'smooth', block:'center' }), 400);
  }

  /* ── 4. 오버레이 ── */
  function showOverlay(entries) {
    document.getElementById('__plr3ov__')?.remove();
    const ov = document.createElement('div');
    ov.id = '__plr3ov__';
    const sfLabel = isMobileAd ? '📱 모바일 더보기' : isMobileMain ? '📱 모바일' : isPCad ? '🖥️ PC 더보기' : '🖥️ PC 통합';
    Object.assign(ov.style, {
      position:'fixed', top:'14px', right:'16px', zIndex:'2147483647',
      background:'rgba(255,255,255,.97)', border:'1.5px solid #e0e4ef',
      borderRadius:'14px', padding:'13px 15px', minWidth:'230px', maxWidth:'290px',
      boxShadow:'0 8px 32px rgba(30,37,64,.14)',
      fontFamily:"'Noto Sans KR','Apple SD Gothic Neo',sans-serif",
      color:'#1e2540', fontSize:'13px', lineHeight:'1.5', userSelect:'none',
    });

    ov.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
        <div>
          <span style="font-size:11px;font-weight:700;color:#9ba3bc">📊 파워링크 순위 체커</span>
          <span style="font-size:10px;color:#c8cfe0;margin-left:5px;background:#f0f2f8;padding:1px 5px;border-radius:3px">${sfLabel}</span>
        </div>
        <button id="__plr3cl__" style="background:none;border:none;color:#c8cfe0;cursor:pointer;font-size:18px;line-height:1;padding:0 2px">×</button>
      </div>`;

    entries.forEach(({ advertiser, keyword, currentRank, targetRank, diff }) => {
      const better = currentRank !== null && currentRank < targetRank;
      const good   = currentRank !== null && currentRank === targetRank;
      const miss   = currentRank === null;
      const clr    = miss ? '#d97706' : better ? '#16a34a' : good ? '#2563eb' : '#dc2626';
      const rtxt   = miss ? '미노출' : `${currentRank}위`;
      const icon   = miss ? '⚠️' : better ? '🟢' : good ? '✅' : '❌';
      const dEl    = diff==='▲' ? `<span style="color:#16a34a;font-weight:700">▲</span>`
                   : diff==='▼' ? `<span style="color:#dc2626;font-weight:700">▼</span>`
                   : `<span style="color:#c8cfe0">—</span>`;

      const row = document.createElement('div');
      row.style.cssText = 'background:#f4f6fb;border:1.5px solid #e0e4ef;border-radius:9px;padding:9px 11px;margin-bottom:6px;';
      row.innerHTML = `
        <div style="font-size:11px;color:#5a6480;margin-bottom:4px">
          ${icon} ${advertiser ? `<b style="color:#1e2540">${esc(advertiser)}</b> · ` : ''}${esc(keyword)}
        </div>
        <div style="display:flex;align-items:baseline;gap:7px">
          <span style="font-size:26px;font-weight:800;color:${clr};font-family:monospace;line-height:1">${rtxt}</span>
          <span style="font-size:11px;color:#9ba3bc">목표 ${targetRank}위</span>
          <span style="margin-left:auto;font-size:13px">${dEl}</span>
        </div>`;
      ov.appendChild(row);
    });

    const ts = document.createElement('div');
    ts.style.cssText = 'font-size:10px;color:#c8cfe0;margin-top:2px;font-family:monospace;';
    ts.textContent = new Date().toLocaleString('ko-KR', { month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' }) + ' 기준';
    ov.appendChild(ts);
    document.body.appendChild(ov);

    document.getElementById('__plr3cl__').addEventListener('click', () => {
      ov.style.cssText += ';opacity:0;transition:opacity .2s';
      setTimeout(() => ov.remove(), 220);
    });

    setTimeout(() => {
      if (!document.getElementById('__plr3ov__')) return;
      const f   = entries[0];
      const clr = f.currentRank === null ? '#d97706' : f.currentRank < f.targetRank ? '#16a34a' : f.currentRank === f.targetRank ? '#2563eb' : '#dc2626';
      const rt  = f.currentRank === null ? '미노출' : `${f.currentRank}위`;
      ov.style.padding = '8px 13px';
      ov.innerHTML = `<div style="display:flex;align-items:center;gap:7px;cursor:pointer" id="__plr3exp__">
        <span>📊</span>
        <span style="font-size:12px;font-weight:700;color:${clr}">${esc(f.keyword)}: ${rt}</span>
        <span style="margin-left:auto;font-size:10px;color:#c8cfe0">펼치기</span>
      </div>`;
      document.getElementById('__plr3exp__')?.addEventListener('click', () => { ov.remove(); showOverlay(entries); });
    }, 12000);
  }

  /* ── 5. 메인 실행 ── */
  async function run() {
    const data     = await chrome.storage.local.get([SK, '__plrank_scan_tabs__']);
    const all      = data[SK] || [];
    const scanTabs = data.__plrank_scan_tabs__ || {};
    if (!all.length) { log('키워드 없음'); return; }

    // 자동 스캔 판별: scanTabs 값에 현재 검색어가 있으면 자동 스캔
    const isAutoScan = Object.values(scanTabs).some(
      kw => kw?.trim().toLowerCase() === currentQuery.toLowerCase()
    );
    log('자동 스캔:', isAutoScan);

    // 현재 탭의 지면 판별
    // - m.ad.search.naver.com → useMobile=true
    // - ad.search.naver.com   → usePowerlink=true, useMobile=false
    // - search.naver.com      → usePowerlink=false, useMobile=false
    const norm2 = s => s.trim().replace(/\s+/g, ' ').toLowerCase();
    const matched = all.map((item, idx) => ({ item, idx }))
      .filter(({ item }) => {
        if (norm2(item.keyword) !== norm2(currentQuery)) return false;
        // 지면 일치 여부: 현재 탭의 지면 = 항목의 지면 설정
        const itemMobile    = !!item.useMobile;
        const itemPowerlink = !!item.usePowerlink;
        if (isMobileAd)   return itemMobile === true;
        if (isMobileMain) return itemMobile === true;
        if (isPCad)       return itemMobile === false && itemPowerlink === true;
        return itemMobile === false && itemPowerlink === false; // PC 통합검색
      });

    if (!matched.length) { log('일치 키워드 없음'); return; }

    const adItems = collectAdItems();
    adItems.forEach((el, i) => log(`[${i+1}위] cite="${el.querySelector('cite')?.textContent?.trim()}" | ${el.textContent.slice(0,50).replace(/\s+/g,' ')}`));

    const results = [];
    for (const { item, idx } of matched) {
      let foundRank = null, foundEl = null;
      for (let i = 0; i < adItems.length; i++) {
        if (matchUrl(adItems[i], item.url)) {
          foundRank = i + 1; foundEl = adItems[i];
          log(`✅ ${item.url} → ${foundRank}위`); break;
        }
      }
      if (!foundEl) warn(`❌ 미매칭: ${item.url}`);

      const prev = item.lastRank;
      const diff = (prev != null && foundRank != null)
        ? foundRank < prev ? '▲' : foundRank > prev ? '▼' : '-' : '-';

      // ★ Race condition 방지: 쓰기 직전에 storage를 다시 읽어서 최신 상태에 반영
      // 동시에 다른 탭이 같은 배열을 수정했을 수 있으므로 항상 최신값 기준으로 업데이트
      const fresh = await chrome.storage.local.get(SK);
      const freshAll = fresh[SK] || [];
      const freshIdx = freshAll.findIndex(k => k.id === item.id);
      if (freshIdx !== -1) {
        freshAll[freshIdx] = {
          ...freshAll[freshIdx],
          prevRank: freshAll[freshIdx].lastRank,
          lastRank: foundRank,
          diff,
          lastCheckedAt: Date.now()
        };
        await chrome.storage.local.set({ [SK]: freshAll });
      } else {
        // fallback: id 없는 기존 데이터
        all[idx] = { ...item, prevRank: item.lastRank, lastRank: foundRank, diff, lastCheckedAt: Date.now() };
        await chrome.storage.local.set({ [SK]: all });
      }

      if (!isAutoScan && foundEl) highlight(foundEl, foundRank, item.targetRank || 3, item.advertiser || '');
      results.push({ advertiser: item.advertiser||'', keyword: item.keyword, currentRank: foundRank, targetRank: item.targetRank||3, diff });
    }

    if (!isAutoScan && results.length) showOverlay(results);

    if (isAutoScan) {
      // 완료 신호: 키워드별로 하나만 보냄
      // sidepanel.js에서 scanTotal을 탭 수 기준으로 카운트하므로 탭당 한 번만 발송
      const doneKey = `__plrank_done_${encodeURIComponent(currentQuery)}__`;
      await chrome.storage.local.set({ [doneKey]: { keyword: currentQuery, ts: Date.now() } });
      log('🏁 완료:', doneKey);
    }
  }

  /* ── 6. 타이밍 ── */
  function waitAndRun() {
    if (collectAdItems().length > 0) { run(); return; }
    let done = false;
    const mo = new MutationObserver(() => {
      if (done) return;
      if (collectAdItems().length > 0) { done = true; mo.disconnect(); run(); }
    });
    mo.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => { if (!done) { done = true; mo.disconnect(); run(); } }, 8000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', waitAndRun);
  else waitAndRun();

  function esc(s) { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
})();
