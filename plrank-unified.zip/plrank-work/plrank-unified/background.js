// background.js — Service Worker
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
